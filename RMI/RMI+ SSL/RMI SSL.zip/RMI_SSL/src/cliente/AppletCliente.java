/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.TextField;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Level;
import java.util.logging.Logger;
import seguridad.CifradoDatos;
import seguridad.DesencriptarDatos;
import servidor.TestRemote;
import ssl.SSLClient;

/**
 *
 * @author manue
 */
public class AppletCliente extends Applet {
    String sal;
     Label titulo = new Label("Gestion de prestamo");
     Label mensaje = new Label("Ingrese salario");
     Label resultado = new Label("");
     TextField salario = new TextField(20);
     Button button = new Button("Enviar");
     SSLClient sslcc ;
     
     public void init(){
        try {
            sslcc= new SSLClient("localhost",5557);
        } catch (Exception ex) {
            Logger.getLogger(AppletCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
     add(titulo);
     add(mensaje);
     add(salario);
     add(button);
     add(resultado);
     }
     
      public boolean action(Event event, Object ob) {

        if (event.target == button) {
           
                sal = salario.getText();
            try {
                operar();
            } catch (RemoteException ex) {
                Logger.getLogger(AppletCliente.class.getName()).log(Level.SEVERE, null, ex);
            } catch (NotBoundException ex) {
                Logger.getLogger(AppletCliente.class.getName()).log(Level.SEVERE, null, ex);
            }
                return true;
          
        }
        return false;
    }
       public void paint(Graphics g) {

    }
       
       public void operar() throws RemoteException, NotBoundException{
       
       resultado.setText(sslcc.operar(sal));
   
       
            

    }
    
    
}
