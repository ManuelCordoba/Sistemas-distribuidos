package ssl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.security.KeyStore;

import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import seguridad.CifradoDatos;
import seguridad.DesencriptarDatos;
import servidor.TestRemote;

public class SSLClient {
   private SSLSocket client;

   public SSLClient(String address, int port) throws Exception {

      KeyStore keyStore = KeyStore.getInstance("JKS");
      keyStore.load(new FileInputStream("src/main/certs/client/clientKey.jks"),
            "clientpass".toCharArray());

      KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
      kmf.init(keyStore, "clientpass".toCharArray());

      KeyStore trustedStore = KeyStore.getInstance("JKS");
      trustedStore.load(new FileInputStream(
            "src/main/certs/client/clientTrustedCerts.jks"), "clientpass"
            .toCharArray());

      TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
      tmf.init(trustedStore);

      SSLContext sc = SSLContext.getInstance("TLS");
      TrustManager[] trustManagers = tmf.getTrustManagers();
      KeyManager[] keyManagers = kmf.getKeyManagers();
      sc.init(keyManagers, trustManagers, null);

      SSLSocketFactory ssf = sc.getSocketFactory();
      client = (SSLSocket) ssf.createSocket(address, port);
      client.startHandshake();
   }

   
      public void startClientWorking(){
      System.out.println("Empezo Cliente");
      new Thread() {
         public void run() {
            try {
               PrintWriter output = new PrintWriter(client.getOutputStream());
               output.println("Manuel");
               output.flush();
               System.out.println("Cliente envio");
               BufferedReader input = new BufferedReader(new InputStreamReader(
                     client.getInputStream()));
               String received = input.readLine();
               System.out.println("Recivio : " + received);
               client.close();
            } catch (IOException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }
         }
      }.start();
   }
   
      public String operar(String sal) throws RemoteException, NotBoundException{
   Registry registry = LocateRegistry.getRegistry();

        TestRemote testRemote1 = (TestRemote) registry.lookup("datoKey");
       
        
            CifradoDatos cifradoDatos = new CifradoDatos(sal);
            
                String re=testRemote1.calcularPrestamo(cifradoDatos.Cifrado());
                System.out.println(re);
                DesencriptarDatos desencriptarDatos = new DesencriptarDatos(re);
                return(desencriptarDatos.Cifrado());
}
   

}
