package servicio;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/movies")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class JsonResponse {
	
	@GET
	public Response sayHello() {
		return Response.ok("{\n" + 
				"  \"peliculas\": [\n" + 
				"    {\n" + 
				"      \"id\": 1,\n" + 
				"      \"nombre\": \"El sexto sentido\",\n" + 
				"      \"director\": \"M. Night Shyamalan\",\n" + 
				"      \"clasificacion\": \"Drama\"\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"id\": 2,\n" + 
				"      \"nombre\": \"Pulp Fiction\",\n" + 
				"      \"director\": \"Tarantino\",\n" + 
				"      \"clasificacion\": \"Acci�n\"\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"id\": 3,\n" + 
				"      \"nombre\": \"Todo Sobre Mi Madre\",\n" + 
				"      \"director\": \"Almodobar\",\n" + 
				"      \"clasificacion\": \"Drama\"\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"id\": 4,\n" + 
				"      \"nombre\": \"300\",\n" + 
				"      \"director\": \"Zack Snyder\",\n" + 
				"      \"clasificacion\": \"Acci�n\"\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"id\": 5,\n" + 
				"      \"nombre\": \"El silencio de los corderos\",\n" + 
				"      \"director\": \"Jonathan Demme\",\n" + 
				"      \"clasificacion\": \"Drama\"\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"id\": 6,\n" + 
				"      \"nombre\": \"Forrest Gump\",\n" + 
				"      \"director\": \"Robert Zemeckis\",\n" + 
				"      \"clasificacion\": \"Comedia\"\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"id\": 7,\n" + 
				"      \"nombre\": \"Las Hurdes\",\n" + 
				"      \"director\": \"Luis Bu�uel\",\n" + 
				"      \"clasificacion\": \"Documental\"\n" + 
				"    }\n" + 
				"  ],\n" + 
				"  \"clasificaciones\": [\n" + 
				"    {\n" + 
				"      \"nombre\": \"Drama\",\n" + 
				"      \"id\": 1\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"nombre\": \"Comedia\",\n" + 
				"      \"id\": 2\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"nombre\": \"Documental\",\n" + 
				"      \"id\": 3\n" + 
				"    },\n" + 
				"    {\n" + 
				"      \"nombre\": \"Acci�n\",\n" + 
				"      \"id\": 4\n" + 
				"    }\n" + 
				"  ]\n" + 
				"}", MediaType.APPLICATION_JSON).build();
	}
	
	
}